# mypackage/mymodule.py

def hello():
    return "This is a dummy package created by Atharva"
