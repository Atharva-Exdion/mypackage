# mypackage/mymodule.py

def hello():
    return "Hello, world!"
