# mypackage/__init__.py

from .mymodule import hello
